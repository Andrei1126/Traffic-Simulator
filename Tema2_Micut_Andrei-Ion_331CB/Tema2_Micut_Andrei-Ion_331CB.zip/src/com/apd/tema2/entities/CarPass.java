/*
Micut Andrei-Ion
Grupa 331CB
 */

package com.apd.tema2.entities;

public enum CarPass {
    GOT_RED,
    GOT_GREEN
}
